function _typeof(e){return _typeof="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},_typeof(e)
/**
* vkBeautify - javascript plugin to pretty-print or minify text in XML, JSON, CSS and SQL formats.
*  
* Version - 0.99.00.beta 
* Copyright (c) 2012 Vadim Kiryukhin
* vkiryukhin @ gmail.com
* http://www.eslinstructor.net/vkbeautify/
* 
* MIT license:
*   http://www.opensource.org/licenses/mit-license.php
*
*   Pretty print
*
*        vkbeautify.xml(text [,indent_pattern]);
*        vkbeautify.json(text [,indent_pattern]);
*        vkbeautify.css(text [,indent_pattern]);
*        vkbeautify.sql(text [,indent_pattern]);
*
*        @text - String; text to beatufy;
*        @indent_pattern - Integer | String;
*                Integer:  number of white spaces;
*                String:   character string to visualize indentation ( can also be a set of white spaces )
*   Minify
*
*        vkbeautify.xmlmin(text [,preserve_comments]);
*        vkbeautify.jsonmin(text);
*        vkbeautify.cssmin(text [,preserve_comments]);
*        vkbeautify.sqlmin(text);
*
*        @text - String; text to minify;
*        @preserve_comments - Bool; [optional];
*                Set this flag to true to prevent removing comments from @text ( minxml and mincss functions only. )
*
*   Examples:
*        vkbeautify.xml(text); // pretty print XML
*        vkbeautify.json(text, 4 ); // pretty print JSON
*        vkbeautify.css(text, '. . . .'); // pretty print CSS
*        vkbeautify.sql(text, '----'); // pretty print SQL
*
*        vkbeautify.xmlmin(text, true);// minify XML, preserve comments
*        vkbeautify.jsonmin(text);// minify JSON
*        vkbeautify.cssmin(text);// minify CSS, remove comments ( default )
*        vkbeautify.sqlmin(text);// minify SQL
*
*/}!function(){function e(e){var r="    ";if(isNaN(parseInt(e)))r=e;else switch(e){case 1:r=" ";break;case 2:r="  ";break;case 3:r="   ";break;case 4:r="    ";break;case 5:r="     ";break;case 6:r="      ";break;case 7:r="       ";break;case 8:r="        ";break;case 9:r="         ";break;case 10:r="          ";break;case 11:r="           ";break;case 12:r="            "}var c=["\n"];for(ix=0;ix<100;ix++)c.push(c[ix]+r);return c}function r(){this.step="\t",this.shift=e(this.step)}function c(e,r){return r-(e.replace(/\(/g,"").length-e.replace(/\)/g,"").length)}function a(e,r){return e.replace(/\s{1,}/g," ").replace(/ AND /gi,"~::~"+r+r+"AND ").replace(/ BETWEEN /gi,"~::~"+r+"BETWEEN ").replace(/ CASE /gi,"~::~"+r+"CASE ").replace(/ ELSE /gi,"~::~"+r+"ELSE ").replace(/ END /gi,"~::~"+r+"END ").replace(/ FROM /gi,"~::~FROM ").replace(/ GROUP\s{1,}BY/gi,"~::~GROUP BY ").replace(/ HAVING /gi,"~::~HAVING ").replace(/ IN /gi," IN ").replace(/ JOIN /gi,"~::~JOIN ").replace(/ CROSS~::~{1,}JOIN /gi,"~::~CROSS JOIN ").replace(/ INNER~::~{1,}JOIN /gi,"~::~INNER JOIN ").replace(/ LEFT~::~{1,}JOIN /gi,"~::~LEFT JOIN ").replace(/ RIGHT~::~{1,}JOIN /gi,"~::~RIGHT JOIN ").replace(/ ON /gi,"~::~"+r+"ON ").replace(/ OR /gi,"~::~"+r+r+"OR ").replace(/ ORDER\s{1,}BY/gi,"~::~ORDER BY ").replace(/ OVER /gi,"~::~"+r+"OVER ").replace(/\(\s{0,}SELECT /gi,"~::~(SELECT ").replace(/\)\s{0,}SELECT /gi,")~::~SELECT ").replace(/ THEN /gi," THEN~::~"+r).replace(/ UNION\s*/gi,"~::~UNION~::~").replace(/~::~UNION~::~ALL /gi,"~::~UNION ALL~::~").replace(/ USING /gi,"~::~USING ").replace(/ WHEN /gi,"~::~"+r+"WHEN ").replace(/ WHERE /gi,"~::~WHERE ").replace(/ WITH /gi,"~::~WITH ").replace(/ ALL /gi," ALL ").replace(/ AS /gi," AS ").replace(/ ASC /gi," ASC ").replace(/ DESC /gi," DESC ").replace(/ DISTINCT /gi," DISTINCT ").replace(/ EXISTS /gi," EXISTS ").replace(/ NOT /gi," NOT ").replace(/ NULL /gi," NULL ").replace(/ LIKE /gi," LIKE ").replace(/\s{0,}SELECT /gi,"SELECT ").replace(/\s{0,}UPDATE /gi,"UPDATE ").replace(/ SET /gi," SET ").replace(/~::~{1,}/g,"~::~").split("~::~")}r.prototype.xml=function(r,c){var a=r.replace(/>\s{0,}</g,"><").replace(/</g,"~::~<").replace(/\s*xmlns\:/g,"~::~xmlns:").replace(/\s*xmlns\=/g,"~::~xmlns=").split("~::~"),p=a.length,l=!1,s=0,t="",n=0,i=c?e(c):this.shift;for(n=0;n<p;n++)a[n].search(/<!/)>-1?(t+=i[s]+a[n],l=!0,(a[n].search(/-->/)>-1||a[n].search(/\]>/)>-1||a[n].search(/!DOCTYPE/)>-1)&&(l=!1)):a[n].search(/-->/)>-1||a[n].search(/\]>/)>-1?(t+=a[n],l=!1):/^<\w/.exec(a[n-1])&&/^<\/\w/.exec(a[n])&&/^<[\w:\-\.\,]+/.exec(a[n-1])==/^<\/[\w:\-\.\,]+/.exec(a[n])[0].replace("/","")?(t+=a[n],l||s--):a[n].search(/<\w/)>-1&&-1==a[n].search(/<\//)&&-1==a[n].search(/\/>/)?t=t+=l?a[n]:i[s++]+a[n]:a[n].search(/<\w/)>-1&&a[n].search(/<\//)>-1?t=t+=l?a[n]:i[s]+a[n]:a[n].search(/<\//)>-1?t=t+=l?a[n]:i[--s]+a[n]:a[n].search(/\/>/)>-1?t=t+=l?a[n]:i[s]+a[n]:a[n].search(/<\?/)>-1||a[n].search(/xmlns\:/)>-1||a[n].search(/xmlns\=/)>-1?t+=i[s]+a[n]:t+=a[n];return"\n"==t[0]?t.slice(1):t},r.prototype.json=function(e,r){r=r||this.step;return"undefined"==typeof JSON?e:"string"==typeof e?JSON.stringify(JSON.parse(e),null,r):"object"===_typeof(e)?JSON.stringify(e,null,r):e},r.prototype.css=function(r,c){var a=r.replace(/\s{1,}/g," ").replace(/\{/g,"{~::~").replace(/\}/g,"~::~}~::~").replace(/\;/g,";~::~").replace(/\/\*/g,"~::~/*").replace(/\*\//g,"*/~::~").replace(/~::~\s{0,}~::~/g,"~::~").split("~::~"),p=a.length,l=0,s="",t=0,n=c?e(c):this.shift;for(t=0;t<p;t++)/\{/.exec(a[t])?s+=n[l++]+a[t]:/\}/.exec(a[t])?s+=n[--l]+a[t]:(/\*\\/.exec(a[t]),s+=n[l]+a[t]);return s.replace(/^\n{1,}/,"")},r.prototype.sql=function(r,p){var l=r.replace(/\s{1,}/g," ").replace(/\'/gi,"~::~'").split("~::~"),s=l.length,t=[],n=0,i=this.step,g=0,o="",E=0,N=p?e(p):this.shift;for(E=0;E<s;E++)t=E%2?t.concat(l[E]):t.concat(a(l[E],i));for(s=t.length,E=0;E<s;E++){g=c(t[E],g),/\s{0,}\s{0,}SELECT\s{0,}/.exec(t[E])&&(t[E]=t[E].replace(/\,/g,",\n"+i+i)),/\s{0,}\s{0,}SET\s{0,}/.exec(t[E])&&(t[E]=t[E].replace(/\,/g,",\n"+i+i)),/\s{0,}\(\s{0,}SELECT\s{0,}/.exec(t[E])?o+=N[++n]+t[E]:/\'/.exec(t[E])?(g<1&&n&&n--,o+=t[E]):(o+=N[n]+t[E],g<1&&n&&n--)}return o=o.replace(/^\n{1,}/,"").replace(/\n{1,}/g,"\n")},r.prototype.xmlmin=function(e,r){return(r?e:e.replace(/\<![ \r\n\t]*(--([^\-]|[\r\n]|-[^\-])*--[ \r\n\t]*)\>/g,"").replace(/[ \r\n\t]{1,}xmlns/g," xmlns")).replace(/>\s{0,}</g,"><")},r.prototype.jsonmin=function(e){return"undefined"==typeof JSON?e:JSON.stringify(JSON.parse(e),null,0)},r.prototype.cssmin=function(e,r){return(r?e:e.replace(/\/\*([^*]|[\r\n]|(\*+([^*/]|[\r\n])))*\*+\//g,"")).replace(/\s{1,}/g," ").replace(/\{\s{1,}/g,"{").replace(/\}\s{1,}/g,"}").replace(/\;\s{1,}/g,";").replace(/\/\*\s{1,}/g,"/*").replace(/\*\/\s{1,}/g,"*/")},r.prototype.sqlmin=function(e){return e.replace(/\s{1,}/g," ").replace(/\s{1,}\(/,"(").replace(/\s{1,}\)/,")")},window.vkbeautify=new r}();